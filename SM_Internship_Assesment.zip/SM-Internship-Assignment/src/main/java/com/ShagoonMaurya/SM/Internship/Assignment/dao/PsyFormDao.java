package com.ShagoonMaurya.SM.Internship.Assignment.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ShagoonMaurya.SM.Internship.Assignment.entities.PsyForm;

/*public interface PsyFormDao extends JpaRepository<PsyForm, Long>{
	
@Repository
public interface UserRepository extends CrudRepository<User, Long> {}
}
*/
@Repository
public interface PsyFormDao extends CrudRepository<PsyForm, Long> {}

