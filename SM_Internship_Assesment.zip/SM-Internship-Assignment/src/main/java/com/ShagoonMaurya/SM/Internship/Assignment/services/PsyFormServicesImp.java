package com.ShagoonMaurya.SM.Internship.Assignment.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.ShagoonMaurya.SM.Internship.Assignment.dao.PsyFormDao;
import com.ShagoonMaurya.SM.Internship.Assignment.entities.PsyForm;

public class PsyFormServicesImp implements PsyFormService {

	public PsyFormServicesImp() {
		// TODO Auto-generated constructor stub
	}
	@Autowired
	private PsyFormDao psfDao;
	
	@Override
	public PsyForm addPsyForm(PsyForm psf) {
		psfDao.save(psf);
		return psf;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

}
