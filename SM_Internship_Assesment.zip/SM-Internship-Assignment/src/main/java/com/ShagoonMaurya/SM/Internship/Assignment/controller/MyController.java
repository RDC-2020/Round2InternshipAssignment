package com.ShagoonMaurya.SM.Internship.Assignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ShagoonMaurya.SM.Internship.Assignment.entities.PsyForm;
import com.ShagoonMaurya.SM.Internship.Assignment.services.PsyFormService;
import com.ShagoonMaurya.SM.Internship.Assignment.services.PsyFormServicesImp;

@RestController
//@RequestMapping(value = "/service")
public class MyController {
	
	@Autowired(required = false)
	PsyFormServicesImp psfservice;
	
	
	@GetMapping("/home")
	public String home() {
		return "welcome to home";
	}
	

	@PostMapping("/addform")
	public PsyForm addPsycandiate(@Validated @RequestBody PsyForm psf) {
		
		return this.psfservice.addPsyForm(psf);
	}
}
