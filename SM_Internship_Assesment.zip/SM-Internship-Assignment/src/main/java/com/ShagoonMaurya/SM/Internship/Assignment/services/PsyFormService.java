package com.ShagoonMaurya.SM.Internship.Assignment.services;

import com.ShagoonMaurya.SM.Internship.Assignment.entities.PsyForm;

public interface PsyFormService {

	public PsyForm addPsyForm(PsyForm psf);
}
